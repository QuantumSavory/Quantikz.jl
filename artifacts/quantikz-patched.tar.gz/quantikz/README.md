#Quantikz#

The package is quantikz, written by Alastair Kay. Its purpose is to extend tikz with the functionality for drawing quantum circuit diagrams.

It is covered by a CC-BY 4.0 license.

Please see the manual for detailed usage.